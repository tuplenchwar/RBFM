#include <cmath>
#include "rbfm.h"
#include <stdlib.h>
#include "iostream"
#include <string.h>
#include <cassert>

unsigned sizeOfSlotCount = sizeof(unsigned);
unsigned sizeOfSlotNum = sizeof(unsigned);
unsigned sizeOfNextRecordWritePtr = sizeof(unsigned);
// nextRecordWritePtrOffset tells from which byte the recordWritePtr is stored
unsigned nextRecordWritePtrOffset = PAGE_SIZE - sizeOfSlotCount - sizeOfNextRecordWritePtr;

RecordBasedFileManager *RecordBasedFileManager::_rbf_manager = 0;
PagedFileManager *pfm = PagedFileManager::instance();
RecordBasedFileManager *RecordBasedFileManager::instance()
{
    if (!_rbf_manager)
        _rbf_manager = new RecordBasedFileManager();

    return _rbf_manager;
}

RecordBasedFileManager::RecordBasedFileManager()
{
}

RecordBasedFileManager::~RecordBasedFileManager()
{
}

unsigned getSlotCount(const void *pageData)
{
    // last 4 bytes store slotCount
    unsigned slotCount;
    memcpy((char *)&slotCount, (char *)pageData + PAGE_SIZE - sizeOfSlotCount, sizeOfSlotCount);
    return slotCount;
}

bool fitInPage(unsigned nextRecordWritePtr, unsigned slotCount, unsigned recordSize)
{
    // returns true if record can fit in the page
    unsigned slotOffset = PAGE_SIZE - sizeOfSlotCount - sizeOfNextRecordWritePtr - slotCount * sizeOfSlotNum;
    if ((slotOffset - nextRecordWritePtr) > recordSize + sizeOfSlotNum)
    {
        return true;
    }
    return false;
}

void setSlotCount(const void *pageData, unsigned slotCount)
{
    // last 4 bytes store slotCount
    *(unsigned *)((char *)pageData + PAGE_SIZE - sizeOfSlotCount) = slotCount;
}

void setRecordOffsetInSlotNum(void *pageData, unsigned slotNum, unsigned recordOffset)
{
    // this data is stored in the slot number and it tells from which offset the record read starts from
    unsigned slotNumOffset = PAGE_SIZE - sizeOfSlotCount - sizeOfNextRecordWritePtr - (slotNum)*sizeOfSlotCount;
    *(unsigned *)((char *)pageData + slotNumOffset) = recordOffset;
}

unsigned getNextRecordWritePtr(const void *pageData)
{
    // last 8 bytes to last 4 bytes store offset saying where to start writing next record
    unsigned ptr;
    memcpy((char *)&ptr, (char *)pageData + nextRecordWritePtrOffset, sizeOfNextRecordWritePtr);
    return ptr;
}

void setNextRecordWriteOffset(const void *pageData, unsigned offset)
{
    *(unsigned *)((char *)pageData + nextRecordWritePtrOffset) = offset;
}

int getAttributesOffsetSize(const int numAttributes)
{
    // returns the number of bytes required to store the offset of all the attributes' offset
    return numAttributes * sizeof(unsigned);
}

int getBitMapSize(const int numAttributes)
{
    // returns the number of bytes required to store the bitmap for null values representation in the record
    return ceil(double(numAttributes) / CHAR_BIT);
}

unsigned getRecordOffset(void *pageData, unsigned slotNum)
{
    unsigned slotNumbOffset = PAGE_SIZE - sizeOfSlotCount - sizeOfNextRecordWritePtr - (slotNum + 1) * sizeOfSlotCount;
    unsigned ptr;
    memcpy((char *)&ptr, (char *)pageData + slotNumbOffset, sizeOfSlotNum);
    return ptr;
}

int getRecordDataSize(void *pageData, int recordOffset, int numAttributes)
{
    int recordSize;
    int attribOffsetSize = getAttributesOffsetSize(numAttributes);
    memcpy((char *)&recordSize, (char *)pageData + recordOffset + attribOffsetSize - sizeof(int), sizeof(int));
    return recordSize;
}

unsigned createAttrOffsetAndGetRecordSize(const vector<Attribute> &recordDescriptor, const void *data, void *attrOffset)
{
    const int numAttributes = recordDescriptor.size();
    int attributesOffsetSize = getAttributesOffsetSize(numAttributes); // to store the offset where each field ends in the record
    int bitMapSize = getBitMapSize(numAttributes);
    int recordDataSize = bitMapSize;

    for (int i = 0; i < numAttributes; i++)
    {
        AttrType attrType = recordDescriptor[i].type;
        string attrName = recordDescriptor[i].name;
        if (!(((char *)data)[i / 8] & 1 << (7 - i % 8)))
        { // if not null
            if (attrType == TypeVarChar)
            {
                recordDataSize += 4 + *(int *)((char *)data + recordDataSize);
            }
            else
            {
                // int and floats take same space :P
                recordDataSize += sizeof(int);
            }
        }
        *((unsigned *)attrOffset + i) = unsigned(recordDataSize);
    }
    //     attrOffsetSize bitMap
    //              |      |
    // formatted data:  |13 17 21 25|0|8Anteater 25 177.6 6620
    //                    bytes ->  0 1       13  17    21    25
    // recordDataSize = 25
    // recordSize = attributesOffsetSize + recordDataSize
    return attributesOffsetSize + recordDataSize;
}

RC RecordBasedFileManager::createFile(const string &fileName)
{
    return pfm->createFile(fileName);
}

RC RecordBasedFileManager::destroyFile(const string &fileName)
{
    return pfm->destroyFile(fileName);
}

RC RecordBasedFileManager::openFile(const string &fileName, FileHandle &fileHandle)
{
    return pfm->openFile(fileName, fileHandle);
}

RC RecordBasedFileManager::closeFile(FileHandle &fileHandle)
{
    return pfm->closeFile(fileHandle);
}

RC RecordBasedFileManager::insertRecord(FileHandle &fileHandle, const vector<Attribute> &recordDescriptor, const void *data, RID &rid)
{
    int numAttributes = recordDescriptor.size();
    int attrOffsetSize = getAttributesOffsetSize(numAttributes);
    int numPages = fileHandle.getNumberOfPages();

    void *attrOffset = malloc(attrOffsetSize);
    int recordSize = createAttrOffsetAndGetRecordSize(recordDescriptor, data, attrOffset);
    void *formattedRecord = malloc(recordSize);
    memcpy((char *)formattedRecord, attrOffset, attrOffsetSize);
    memcpy((char *)formattedRecord + attrOffsetSize, data, recordSize - attrOffsetSize);
    bool createNewPage = true;
    void *pageData = malloc(PAGE_SIZE);
    if (numPages == 0)
    {

        memset(pageData, 0, PAGE_SIZE);
        memcpy(pageData, formattedRecord, recordSize);
        unsigned slotCount = getSlotCount(pageData);
        unsigned nextWritePtr = getNextRecordWritePtr(pageData);
        slotCount += 1;
        setSlotCount(pageData, slotCount);
        setRecordOffsetInSlotNum(pageData, slotCount, nextWritePtr);
        nextWritePtr += unsigned(recordSize);
        setNextRecordWriteOffset(pageData, nextWritePtr);

        fileHandle.appendPage(pageData);
        rid.pageNum = 0;
        rid.slotNum = slotCount - 1;

        createNewPage = false;
    }
    else
    {
        for (int i = 0; i < numPages; i++)
        {

            memset(pageData, 0, PAGE_SIZE);
            fileHandle.readPage(i, pageData);
            unsigned nextWritePtr = getNextRecordWritePtr(pageData);
            unsigned slotCount = getSlotCount(pageData);
            if (fitInPage(nextWritePtr, slotCount, recordSize))
            {
                memcpy((char *)pageData + nextWritePtr, formattedRecord, recordSize);
                slotCount += 1;
                setSlotCount(pageData, slotCount);
                setRecordOffsetInSlotNum(pageData, slotCount, nextWritePtr);
                nextWritePtr += unsigned(recordSize);
                setNextRecordWriteOffset(pageData, nextWritePtr);

                fileHandle.writePage(i, pageData);
                rid.pageNum = i;
                rid.slotNum = slotCount - 1;

                createNewPage = false;
                break;
            }
        }
        if (createNewPage)
        {
            // if no place works; then append new page

            memset(pageData, 0, PAGE_SIZE);
            memcpy(pageData, formattedRecord, recordSize);
            unsigned slotCount = getSlotCount(pageData);
            unsigned nextWritePtr = getNextRecordWritePtr(pageData);
            slotCount += 1;
            setSlotCount(pageData, slotCount);
            setRecordOffsetInSlotNum(pageData, slotCount, nextWritePtr);
            nextWritePtr += unsigned(recordSize);
            setNextRecordWriteOffset(pageData, nextWritePtr);

            fileHandle.appendPage(pageData);
            rid.pageNum = numPages;
            rid.slotNum = slotCount - 1;
        }
    }
    free(formattedRecord);
    free(attrOffset);
    free(pageData);
    return 0;
}

RC RecordBasedFileManager::readRecord(FileHandle &fileHandle, const vector<Attribute> &recordDescriptor, const RID &rid, void *data)
{
    void *page = malloc(PAGE_SIZE);
    assert(page);

    if (fileHandle.readPage(rid.pageNum, page) == -1)
        return -1;

    int recordOffset = getRecordOffset(page, rid.slotNum);
    int attribOffsetSize = getAttributesOffsetSize(recordDescriptor.size());

    int recordLength = getRecordDataSize(page, recordOffset, recordDescriptor.size());
    assert(recordOffset < PAGE_SIZE);
    assert(recordLength < PAGE_SIZE);

    if (recordOffset >= 0)
    {
        memcpy(data, (char *)page + recordOffset + attribOffsetSize, recordLength);
    }

    free(page);
    return 0;
}

RC RecordBasedFileManager::printRecord(const vector<Attribute> &recordDescriptor, const void *data)
{
    int numAttributes = recordDescriptor.size();
    int bitMapSize = getBitMapSize(numAttributes);
    int offsetCounter = bitMapSize;
    char bitMap[bitMapSize];

    memcpy(&bitMap, data, bitMapSize * sizeof(char));

    for (int i = 0; i < numAttributes; ++i)
    {
        const Attribute &attribute = recordDescriptor[i];
        if ((bitMap[i / 8] >> (7 - i % 8)) & 1)
        {
            cout << attribute.name << ":NULL ";
            continue;
        }
        if (attribute.type == TypeVarChar)
        {
            int varcharlength;
            memcpy(&varcharlength, (char *)data + offsetCounter, sizeof(int));
            offsetCounter += 4;
            char varchar[varcharlength + 1];
            memcpy(&varchar, (char *)data + offsetCounter, varcharlength);
            varchar[varcharlength] = '\0';
            offsetCounter += varcharlength;
            cout << attribute.name << ":" << varchar << " ";
        }
        else if (attribute.type == TypeInt)
        {
            int intValue;
            memcpy(&intValue, (char *)data + offsetCounter, sizeof(int));
            offsetCounter += sizeof(int);
            cout << attribute.name << ":" << intValue << " ";
        }
        else if (attribute.type == TypeReal)
        {
            float realValue;
            memcpy(&realValue, (char *)data + offsetCounter, sizeof(float));
            offsetCounter += sizeof(float);
            cout << attribute.name << ":" << realValue << " ";
        }
    }
    cout << endl;
    return 0;
}

RC RecordBasedFileManager::deleteRecord(FileHandle &fileHandle, const vector<Attribute> &recordDescriptor, const RID &rid)
{
    return -1;
}

RC RecordBasedFileManager::updateRecord(FileHandle &fileHandle, const vector<Attribute> &recordDescriptor, const void *data, const RID &rid)
{
    return -1;
}
